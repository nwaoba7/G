# Editor – terminal + code editor for Android

One full-screen pane at a time. The app opens on the **Terminal**; the **☰** button opens a drawer
to switch to the **Editor** and to browse the Arch Linux file tree.

```
┌ ☰  Terminal ───────────┐      ┌ ☰  main.py ●       SAVE ┐
│ [1][2][3] [+]          │      │ Sora CodeEditor         │
│ TerminalView (Termux)  │      │ (TextMate colours)      │
│ ESC TAB CTRL ALT ←↑↓→  │      │ TAB { } ( ) [ ] " ' ;   │
└────────────────────────┘      └─────────────────────────┘
```

## Project layout
```
build.gradle / settings.gradle / gradle.properties
.github/workflows/build.yml        CI (installs NDK 29 + platform 36, builds the APK)
app/
  build.gradle, src/main/AndroidManifest.xml
  src/main/assets/textmate/        grammars + themes (from Sora's sample app)
  src/main/jniLibs/arm64-v8a/libproot.so      <-- YOU keep yours here (not included)
  src/main/java/dev/you/editor/
    MainActivity.kt                wiring only
    setup/    ProotLauncher, RootfsInstaller, Bootstrap
    terminal/ TerminalPane, TermClient, TermSessions, ExtraKeysBar
    editor/   EditorPane, GuestFs
    ui/       MainScreen, DrawerContent, Util
    service/  KeepAliveService
terminal-emulator/  terminal-view/  Termux libraries, vendored (GPLv3, see THIRD_PARTY/)
```

## Using it
1. Copy everything over your repo (replace `build.gradle`, `app/build.gradle`, manifest,
   `MainActivity.kt`, workflow; add `settings.gradle` and `gradle.properties` if you had none, or merge).
2. Keep your `libproot.so` in `app/src/main/jniLibs/arm64-v8a/`. If you also have a loader, name it `libproot-loader.so`.
3. Keep the GitHub secrets `KS_B64`, `KS_PASS`, `KS_ALIAS`.
4. Push. Install the APK from the Actions artifact.

First launch downloads Arch (~500 MB), checks proot (falls back to `PROOT_NO_SECCOMP=1`
automatically), then configures pacman (`CheckSpace` off, `DisableSandbox`, keyring init) and
opens terminal tab 1. Run `pacman -Syu` yourself afterwards.

## Getting the library sources
* **Termux terminal** – already copied into `terminal-emulator/` and `terminal-view/`
  (termux-app commit in `THIRD_PARTY/SOURCES.txt`). To update:
  ```
  git clone --depth 1 https://github.com/termux/termux-app.git
  cp -r termux-app/terminal-emulator/src/main  <repo>/terminal-emulator/src/
  cp -r termux-app/terminal-view/src/main      <repo>/terminal-view/src/
  ```
  Keep OUR `build.gradle` files in those two folders (they are simplified copies).
  On a phone: github.com/termux/termux-app → Code → Download ZIP, unzip, copy the two `src/main` folders.
* **Sora Editor** – no source needed. It is a Maven Central dependency
  (`io.github.rosemoe:editor` + `language-textmate`, version 0.24.6, in `app/build.gradle`).
  Only the TextMate grammars/themes were copied from
  github.com/Rosemoe/sora-editor → `app/src/main/assets/textmate/`.
  More languages: add the grammar folder there and an entry in `languages.json`.

## Licences
Termux modules: GPLv3 (Apache-2.0 for the parts from Terminal Emulator for Android).
Sora Editor: LGPL 2.1. Fine for personal use; if you share the APK, publish your source.

## Notes
* `targetSdk 28` and `useLegacyPackaging = true` are deliberate – do not change.
* Editor auto-saves when you open another file or leave the app.
* Long-press a terminal tab to close it. A finished session closes with Enter.
* Absolute symlinks inside Arch (e.g. `/bin`) are re-mapped by `GuestFs`, so the file tree works.

package dev.you.editor.editor

import android.app.Activity
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import dev.you.editor.ui.Colors
import dev.you.editor.ui.barButton
import io.github.rosemoe.sora.event.ContentChangeEvent
import io.github.rosemoe.sora.lang.EmptyLanguage
import io.github.rosemoe.sora.langs.textmate.TextMateColorScheme
import io.github.rosemoe.sora.langs.textmate.TextMateLanguage
import io.github.rosemoe.sora.langs.textmate.registry.FileProviderRegistry
import io.github.rosemoe.sora.langs.textmate.registry.GrammarRegistry
import io.github.rosemoe.sora.langs.textmate.registry.ThemeRegistry
import io.github.rosemoe.sora.langs.textmate.registry.model.ThemeModel
import io.github.rosemoe.sora.langs.textmate.registry.provider.AssetsFileResolver
import io.github.rosemoe.sora.widget.CodeEditor
import org.eclipse.tm4e.core.registry.IThemeSource
import java.io.File

/**
 * The Editor screen: Sora CodeEditor + a row of coding symbols.
 * Built lazily on first use so the app starts straight into the terminal.
 */
class EditorPane(private val activity: Activity) : FrameLayout(activity) {

    interface Listener { fun onFileStateChanged(name: String, dirty: Boolean) }

    var listener: Listener? = null
    var currentFile: File? = null
        private set
    var dirty = false
        private set

    private var editor: CodeEditor? = null
    private var loading = false

    init { setBackgroundColor(Colors.BG) }

    /** Creates the editor view and loads TextMate grammars/themes (once). */
    fun ensureInit() {
        if (editor != null) return
        initTextMate()
        val ed = CodeEditor(activity).apply {
            typefaceText = Typeface.MONOSPACE
            setTextSize(13f)
            isLineNumberEnabled = true
            setWordwrap(false)
            setTabWidth(4)
            colorScheme = TextMateColorScheme.create(ThemeRegistry.getInstance())
            setEditorLanguage(EmptyLanguage())
            subscribeEvent(ContentChangeEvent::class.java) { _, _ ->
                if (!loading && !dirty) { dirty = true; notifyState() }
            }
        }
        editor = ed

        val hint = TextView(activity).apply {
            text = "Open a file from the ☰ menu"
            setTextColor(Colors.TEXT_DIM)
            textSize = 15f
            gravity = android.view.Gravity.CENTER
        }
        val col = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(ed, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(buildSymbolRow(ed))
        }
        addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (currentFile == null) {
            addView(hint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            this.hint = hint
        }
    }

    private var hint: TextView? = null

    private fun buildSymbolRow(ed: CodeEditor): HorizontalScrollView {
        val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        fun sym(label: String, insert: String = label, caret: Int = insert.length) =
            activity.barButton(label) { ed.insertText(insert, caret) }
        listOf(
            sym("TAB", "\t"), sym("{ }", "{}", 1), sym("( )", "()", 1), sym("[ ]", "[]", 1),
            sym("\" \"", "\"\"", 1), sym("' '", "''", 1), sym(";"), sym(":"), sym("="),
            sym("<"), sym(">"), sym("/"), sym("\\"), sym("|"), sym("&"), sym("_"), sym("#"),
            activity.barButton("UNDO") { if (ed.canUndo()) ed.undo() }
        ).forEach { row.addView(it) }
        return HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Colors.BAR)
            addView(row)
        }
    }

    // ---------------- file operations ----------------

    fun open(file: File) {
        ensureInit()
        val ed = editor ?: return
        saveIfDirty()
        if (file.length() > MAX_BYTES) {
            Toast.makeText(activity, "File too large (> ${MAX_BYTES shr 20} MB)", Toast.LENGTH_LONG).show()
            return
        }
        val bytes = try { file.readBytes() } catch (e: Exception) {
            Toast.makeText(activity, "Cannot read: ${e.message}", Toast.LENGTH_LONG).show(); return
        }
        if (bytes.take(8000).any { it == 0.toByte() }) {
            Toast.makeText(activity, "Binary file - not opened", Toast.LENGTH_LONG).show()
            return
        }
        loading = true
        try {
            ed.setEditorLanguage(languageFor(file))
            ed.setText(String(bytes, Charsets.UTF_8))
        } finally { loading = false }
        currentFile = file
        dirty = false
        hint?.let { removeView(it); hint = null }
        notifyState()
    }

    fun save(): Boolean {
        val f = currentFile ?: return false
        val ed = editor ?: return false
        return try {
            f.writeText(ed.text.toString(), Charsets.UTF_8)
            dirty = false
            notifyState()
            true
        } catch (e: Exception) {
            Toast.makeText(activity, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    fun saveIfDirty() { if (dirty) save() }

    /** Called when a file is deleted/renamed in the tree. */
    fun forget(file: File) {
        if (currentFile?.absolutePath?.startsWith(file.absolutePath) == true) {
            currentFile = null
            dirty = false
            loading = true
            editor?.setText("")
            loading = false
            notifyState()
        }
    }

    private fun notifyState() {
        listener?.onFileStateChanged(currentFile?.name ?: "Editor", dirty)
    }

    private fun languageFor(file: File): io.github.rosemoe.sora.lang.Language {
        val scope = when (file.extension.lowercase()) {
            "java" -> "source.java"
            "kt", "kts" -> "source.kotlin"
            "py" -> "source.python"
            "xml" -> "text.xml"
            "html", "htm" -> "text.html.basic"
            "js", "mjs", "json" -> "source.js"
            "md", "markdown" -> "text.html.markdown"
            else -> null
        } ?: return EmptyLanguage()
        return try { TextMateLanguage.create(scope, true) } catch (e: Exception) { EmptyLanguage() }
    }

    companion object {
        private const val MAX_BYTES = 2L * 1024 * 1024
        private var textMateReady = false

        /** Loads the grammars + themes bundled in assets/textmate (once per process). */
        private fun initTextMate(ctxAssets: android.content.res.AssetManager) {
            if (textMateReady) return
            FileProviderRegistry.getInstance().addFileProvider(AssetsFileResolver(ctxAssets))
            val themes = ThemeRegistry.getInstance()
            for ((name, dark) in listOf("darcula" to true, "quietlight" to false)) {
                val path = "textmate/$name.json"
                themes.loadTheme(
                    ThemeModel(
                        IThemeSource.fromInputStream(
                            FileProviderRegistry.getInstance().tryGetInputStream(path), path, null
                        ), name
                    ).apply { isDark = dark }
                )
            }
            themes.setTheme("darcula")
            GrammarRegistry.getInstance().loadGrammars("textmate/languages.json")
            textMateReady = true
        }
    }

    private fun initTextMate() = initTextMate(activity.applicationContext.assets)
}

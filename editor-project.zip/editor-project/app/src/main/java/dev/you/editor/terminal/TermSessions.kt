package dev.you.editor.terminal

import com.termux.terminal.TerminalSession

/**
 * Process-wide list of terminal sessions. Lives outside the Activity so shells
 * survive an Activity re-creation; the UI just re-attaches to them.
 */
object TermSessions {
    const val MAX = 5
    val sessions = ArrayList<TerminalSession>()
    var current: TerminalSession? = null
    private var counter = 0

    fun nextName(): String = (++counter).toString()
}

package dev.you.editor.terminal

import android.content.Context
import android.view.KeyEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.termux.terminal.KeyHandler
import dev.you.editor.ui.Colors
import dev.you.editor.ui.barButton
import dev.you.editor.ui.dp

/** Esc / Tab / Ctrl / Alt / arrows / symbols row shown under the terminal. */
class ExtraKeysBar(
    ctx: Context,
    private val sendKey: (keyCode: Int, keyMod: Int) -> Unit,
    private val sendText: (String) -> Unit,
    private val paste: () -> Unit
) : HorizontalScrollView(ctx) {

    private var ctrl = false
    private var alt = false
    private lateinit var ctrlBtn: TextView
    private lateinit var altBtn: TextView

    init {
        isHorizontalScrollBarEnabled = false
        setBackgroundColor(Colors.BAR)
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

        fun key(label: String, code: Int) = ctx.barButton(label) { press(code) }
        fun sym(label: String, text: String = label) = ctx.barButton(label) { type(text) }

        ctrlBtn = ctx.barButton("CTRL") { ctrl = !ctrl; refresh() }
        altBtn = ctx.barButton("ALT") { alt = !alt; refresh() }

        listOf<View>(
            key("ESC", KeyEvent.KEYCODE_ESCAPE),
            key("TAB", KeyEvent.KEYCODE_TAB),
            ctrlBtn, altBtn,
            key("←", KeyEvent.KEYCODE_DPAD_LEFT),
            key("↓", KeyEvent.KEYCODE_DPAD_DOWN),
            key("↑", KeyEvent.KEYCODE_DPAD_UP),
            key("→", KeyEvent.KEYCODE_DPAD_RIGHT),
            key("HOME", KeyEvent.KEYCODE_MOVE_HOME),
            key("END", KeyEvent.KEYCODE_MOVE_END),
            key("PGUP", KeyEvent.KEYCODE_PAGE_UP),
            key("PGDN", KeyEvent.KEYCODE_PAGE_DOWN),
            sym("-"), sym("/"), sym("|"), sym("~"), sym("\\"), sym("$"), sym("&"),
            ctx.barButton("PASTE") { paste() }
        ).forEach { row.addView(it) }
        addView(row)
        minimumHeight = ctx.dp(40)
    }

    /** Called by the terminal when the soft keyboard types a key: consume one-shot Ctrl. */
    fun consumeCtrl(): Boolean { val v = ctrl; if (v) { ctrl = false; refresh() }; return v }
    fun consumeAlt(): Boolean { val v = alt; if (v) { alt = false; refresh() }; return v }

    private fun refresh() {
        ctrlBtn.setTextColor(if (ctrl) Colors.ACCENT else Colors.TEXT)
        altBtn.setTextColor(if (alt) Colors.ACCENT else Colors.TEXT)
    }

    private fun press(keyCode: Int) {
        var mod = 0
        if (ctrl) mod = mod or KeyHandler.KEYMOD_CTRL
        if (alt) mod = mod or KeyHandler.KEYMOD_ALT
        ctrl = false; alt = false; refresh()
        sendKey(keyCode, mod)
    }

    private fun type(s: String) {
        var out = s
        if (ctrl && s.length == 1) {
            val c = s[0]
            out = when (c) {
                in 'a'..'z' -> (c - 'a' + 1).toChar().toString()
                in 'A'..'Z' -> (c - 'A' + 1).toChar().toString()
                '[' -> "\u001b"
                '\\' -> "\u001c"
                ']' -> "\u001d"
                else -> s
            }
        }
        if (alt) out = "\u001b$out"
        ctrl = false; alt = false; refresh()
        sendText(out)
    }
}

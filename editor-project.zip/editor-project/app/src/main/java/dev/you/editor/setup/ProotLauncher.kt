package dev.you.editor.setup

import android.content.Context
import java.io.File

/**
 * Knows how to start things inside the Arch rootfs through proot.
 * Used both for blocking one-off commands (setup) and to build the command line
 * for interactive terminal sessions.
 */
class ProotLauncher(private val ctx: Context) {

    private val nativeDir = ctx.applicationInfo.nativeLibraryDir
    val proot = File(nativeDir, "libproot.so")
    private val loader = File(nativeDir, "libproot-loader.so")   // optional, only if you ship one
    val rootDir = File(ctx.filesDir, "arch")
    private val tmpDir = File(ctx.filesDir, "tmp")
    private val prefs = ctx.getSharedPreferences("editor", Context.MODE_PRIVATE)

    /** Set when proot only works with PROOT_NO_SECCOMP=1 on this phone. */
    var noSeccomp: Boolean
        get() = prefs.getBoolean("no_seccomp", false)
        private set(v) { prefs.edit().putBoolean("no_seccomp", v).apply() }

    var probed: Boolean
        get() = prefs.getBoolean("proot_probed", false)
        private set(v) { prefs.edit().putBoolean("proot_probed", v).apply() }

    var setupDone: Boolean
        get() = prefs.getBoolean("setup_done", false)
        set(v) { prefs.edit().putBoolean("setup_done", v).apply() }

    /** Command line + env for a terminal tab (used by Termux TerminalSession). */
    class Spec(val path: String, val cwd: String, val args: Array<String>, val env: Array<String>)

    fun interactiveShell(): Spec {
        val args = prootArgs(guestEnv(listOf("/bin/bash", "-l")))
        val env = hostEnv(noSeccomp).map { "${it.key}=${it.value}" }
        return Spec(proot.path, ctx.filesDir.path, args.toTypedArray(), env.toTypedArray())
    }

    /** Runs a command in the guest and waits. Output lines go to [onLine]. Returns exit code. */
    fun runBlocking(
        guestCmd: List<String>,
        useNoSeccomp: Boolean = noSeccomp,
        onLine: (String) -> Unit
    ): Int {
        val pb = ProcessBuilder(prootArgs(guestEnv(guestCmd))).redirectErrorStream(true)
        pb.directory(ctx.filesDir)
        pb.environment().apply { clear(); putAll(hostEnv(useNoSeccomp)) }
        val p = pb.start()
        p.inputStream.bufferedReader().forEachLine(onLine)
        return p.waitFor()
    }

    /** Finds out whether proot works here, and whether it needs PROOT_NO_SECCOMP. */
    fun probe(onLine: (String) -> Unit): Boolean {
        for (ns in listOf(false, true)) {
            val code = try {
                runBlocking(listOf("/bin/sh", "-c", "uname -a; head -2 /etc/os-release"), ns, onLine)
            } catch (e: Throwable) {
                onLine("proot could not start: $e"); -1
            }
            if (code == 0) {
                noSeccomp = ns
                probed = true
                onLine(if (ns) "proot OK (using PROOT_NO_SECCOMP=1)" else "proot OK")
                return true
            }
            onLine("proot failed (exit $code)${if (!ns) ", retrying with PROOT_NO_SECCOMP=1..." else ""}")
        }
        return false
    }

    fun prootVersion(): String = try {
        val p = ProcessBuilder(proot.path, "--version").redirectErrorStream(true).start()
        p.inputStream.bufferedReader().readText().trim().lineSequence().firstOrNull() ?: "(no output)"
    } catch (e: Throwable) { "failed: $e" }

    // ---- internals ----

    private fun prootArgs(guestCmd: List<String>): List<String> = listOf(
        proot.path, "--link2symlink", "-0", "--kill-on-exit",
        "-r", rootDir.path,
        "-b", "/dev", "-b", "/proc", "-b", "/sys",
        "-w", "/root"
    ) + guestCmd

    /** `env -i` gives the guest a clean environment instead of Android's. */
    private fun guestEnv(inner: List<String>): List<String> = listOf(
        "/usr/bin/env", "-i",
        "HOME=/root", "USER=root", "LOGNAME=root", "SHELL=/bin/bash",
        "TERM=xterm-256color", "COLORTERM=truecolor", "LANG=C.UTF-8", "TMPDIR=/tmp",
        "PATH=/usr/local/sbin:/usr/local/bin:/usr/bin"
    ) + inner

    /** Environment for the proot process itself (host side). */
    private fun hostEnv(useNoSeccomp: Boolean): Map<String, String> {
        tmpDir.mkdirs()
        val env = LinkedHashMap<String, String>(System.getenv())
        env["PROOT_TMP_DIR"] = tmpDir.path
        if (loader.exists()) env["PROOT_LOADER"] = loader.path
        if (useNoSeccomp) env["PROOT_NO_SECCOMP"] = "1"
        val old = System.getenv("LD_LIBRARY_PATH")
        env["LD_LIBRARY_PATH"] = if (old.isNullOrEmpty()) nativeDir else "$nativeDir:$old"
        return env
    }
}

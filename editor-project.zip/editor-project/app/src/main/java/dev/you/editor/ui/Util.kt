package dev.you.editor.ui

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.TextView

/** Colours used by all the hand-built views (VS Code-ish dark palette). */
object Colors {
    val BG = Color.parseColor("#1E1E1E")
    val BAR = Color.parseColor("#252526")
    val BAR_ACTIVE = Color.parseColor("#37373D")
    val TEXT = Color.parseColor("#D4D4D4")
    val TEXT_DIM = Color.parseColor("#8A8A8A")
    val ACCENT = Color.parseColor("#569CD6")
    val DIVIDER = Color.parseColor("#3C3C3C")
}

fun Context.dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()
fun View.dp(n: Int): Int = context.dp(n)

/** A flat text "button" that never takes focus (so the soft keyboard stays open). */
fun Context.barButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
    text = label
    setTextColor(Colors.TEXT)
    textSize = 14f
    gravity = Gravity.CENTER
    setPadding(dp(12), dp(8), dp(12), dp(8))
    minWidth = dp(40)
    isFocusable = false
    isFocusableInTouchMode = false
    isClickable = true
    setOnClickListener { onClick() }
}

fun View.roundedBg(color: Int, radiusDp: Int = 6) {
    background = GradientDrawable().apply {
        setColor(color)
        cornerRadius = context.dp(radiusDp).toFloat()
    }
}

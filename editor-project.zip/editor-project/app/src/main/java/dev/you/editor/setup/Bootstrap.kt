package dev.you.editor.setup

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * First-run pipeline: download rootfs -> check proot -> pacman setup.
 * All [Listener] callbacks arrive on the UI thread.
 */
class Bootstrap(
    private val ctx: Context,
    private val launcher: ProotLauncher,
    private val listener: Listener
) {
    interface Listener {
        fun log(line: String)
        fun status(text: String)
        fun busy(busy: Boolean)
        fun ready()
        fun failed()
    }

    companion object { private val running = AtomicBoolean(false) }

    private val ui = Handler(Looper.getMainLooper())
    private val installer = RootfsInstaller(
        ctx, launcher,
        { line -> ui.post { listener.log(line) } },
        { text -> ui.post { listener.status(text) } }
    )

    fun isReady() = installer.isInstalled() && launcher.probed && launcher.setupDone

    fun start() {
        if (isReady()) { listener.ready(); return }
        if (!running.compareAndSet(false, true)) {
            listener.log("Setup is already running in the background...")
            return
        }
        listener.busy(true)
        Thread {
            try {
                File(ctx.filesDir, "rootfs").deleteRecursively()   // leftover from older builds
                ui.post {
                    listener.log("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MODEL}")
                    listener.log("Free space: ${ctx.filesDir.usableSpace shr 20} MB")
                    listener.log("proot exists: ${launcher.proot.exists()}")
                }
                val ver = launcher.prootVersion()
                ui.post { listener.log("proot version: $ver") }

                if (!installer.isInstalled()) {
                    launcher.setupDone = false
                    installer.install()
                }
                if (!launcher.probed) {
                    ui.post { listener.status("Checking proot...") }
                    val ok = launcher.probe { line -> ui.post { listener.log(line) } }
                    if (!ok) throw Exception("proot does not work on this device")
                }
                if (!launcher.setupDone) {
                    ui.post { listener.status("Configuring Arch (pacman keyring)...") }
                    if (!installer.runSetup()) throw Exception("pacman setup failed (see log above)")
                    launcher.setupDone = true
                }
                ui.post { listener.busy(false); listener.ready() }
            } catch (e: Throwable) {
                ui.post {
                    listener.log("ERROR: $e")
                    listener.status("Failed - restart the app to retry")
                    listener.busy(false)
                    listener.failed()
                }
            } finally {
                running.set(false)
            }
        }.start()
    }
}

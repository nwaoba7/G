package dev.you.editor.ui

import android.app.Activity
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.drawerlayout.widget.DrawerLayout
import dev.you.editor.editor.EditorPane
import dev.you.editor.editor.GuestFs
import dev.you.editor.setup.ProotLauncher
import dev.you.editor.terminal.TerminalPane
import java.io.File

enum class Pane { TERMINAL, EDITOR }

/**
 * The whole UI:  [ ☰  title        SAVE ]
 *                [  Terminal  or  Editor  ]   (one full-screen pane at a time)
 * plus a left drawer with the pane switcher and file tree.
 * Both panes stay alive; switching only toggles visibility.
 */
class MainScreen(private val activity: Activity, launcher: ProotLauncher) {

    val terminal = TerminalPane(activity, launcher)
    val editor = EditorPane(activity)
    private val fs = GuestFs(launcher.rootDir)

    private val title = TextView(activity).apply {
        setTextColor(Colors.TEXT)
        textSize = 17f
        setSingleLine()
        gravity = Gravity.CENTER_VERTICAL
    }
    private val saveBtn = activity.barButton("SAVE") { editor.save() }

    private val drawerContent = DrawerContent(activity, fs, object : DrawerContent.Callbacks {
        override fun showTerminal() = show(Pane.TERMINAL)
        override fun showEditor() = show(Pane.EDITOR)
        override fun openFile(file: File) { editor.open(file); show(Pane.EDITOR) }
        override fun fileRemoved(file: File) = editor.forget(file)
    })

    val root = DrawerLayout(activity)
    var pane = Pane.TERMINAL
        private set

    init {
        val topBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Colors.BAR)
            gravity = Gravity.CENTER_VERTICAL
            addView(activity.barButton("☰") { openDrawer() }.apply { textSize = 20f })
            addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            addView(saveBtn)
        }
        val panes = FrameLayout(activity).apply {
            addView(terminal, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(editor, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        val content = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Colors.BG)
            addView(topBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, activity.dp(48)))
            addView(panes, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        root.addView(content, DrawerLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(drawerContent, DrawerLayout.LayoutParams(activity.dp(280), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START))
        root.addDrawerListener(object : DrawerLayout.SimpleDrawerListener() {
            override fun onDrawerOpened(drawerView: View) { drawerContent.refresh() }
        })

        editor.listener = object : EditorPane.Listener {
            override fun onFileStateChanged(name: String, dirty: Boolean) = updateTitle()
        }
        show(Pane.TERMINAL)
    }

    fun show(p: Pane) {
        pane = p
        terminal.visibility = if (p == Pane.TERMINAL) View.VISIBLE else View.GONE
        editor.visibility = if (p == Pane.EDITOR) View.VISIBLE else View.GONE
        if (p == Pane.EDITOR) editor.ensureInit() else terminal.onShown()
        drawerContent.setPane(p == Pane.TERMINAL)
        updateTitle()
        root.closeDrawer(Gravity.START)
    }

    private fun updateTitle() {
        if (pane == Pane.TERMINAL) {
            title.text = "Terminal"
            saveBtn.visibility = View.GONE
        } else {
            val f = editor.currentFile
            title.text = (f?.name ?: "Editor") + if (editor.dirty) " ●" else ""
            saveBtn.visibility = if (f != null) View.VISIBLE else View.GONE
        }
    }

    private fun openDrawer() {
        val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
        root.openDrawer(Gravity.START)
    }

    /** Back button: closes the drawer if open. Returns true if it handled the press. */
    fun onBack(): Boolean {
        if (root.isDrawerOpen(Gravity.START)) { root.closeDrawer(Gravity.START); return true }
        return false
    }
}

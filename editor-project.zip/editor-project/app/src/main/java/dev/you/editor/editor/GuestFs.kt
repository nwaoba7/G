package dev.you.editor.editor

import java.io.File

/**
 * Helpers for browsing the Arch rootfs from Android code.
 * Absolute symlinks inside the rootfs (e.g. /bin -> /usr/bin) point at the *guest* root,
 * but Android would resolve them against the phone's root, so we re-map them here.
 */
class GuestFs(val rootDir: File) {

    val home = File(rootDir, "root")

    /** Follows symlinks the way the guest would. */
    fun resolve(f: File): File {
        var cur = f
        repeat(8) {
            val target = try {
                java.nio.file.Files.readSymbolicLink(cur.toPath()).toString()
            } catch (e: Exception) { return cur }       // not a symlink
            cur = if (target.startsWith("/")) File(rootDir, target) else File(cur.parentFile, target)
        }
        return cur
    }

    fun isDir(f: File) = resolve(f).isDirectory

    /** True if [f] is inside the rootfs (lexically). */
    fun inside(f: File) = f.absoluteFile.toPath().normalize().startsWith(rootDir.toPath())

    /** Directories first, then files, both alphabetical. */
    fun list(dir: File): List<File> =
        (dir.listFiles()?.toList() ?: emptyList())
            .sortedWith(compareBy({ !isDir(it) }, { it.name.lowercase() }))

    /** "/root/foo" style path as the guest sees it. */
    fun guestPath(f: File): String {
        val p = f.absoluteFile.toPath().normalize().toString().removePrefix(rootDir.path)
        return if (p.isEmpty()) "/" else p
    }
}

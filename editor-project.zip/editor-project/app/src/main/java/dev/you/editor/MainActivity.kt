package dev.you.editor

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import dev.you.editor.setup.Bootstrap
import dev.you.editor.setup.ProotLauncher
import dev.you.editor.ui.MainScreen

/**
 * Starts on the Terminal. The ☰ menu switches between Terminal and Editor.
 * All real work lives in setup/, terminal/, editor/ and ui/.
 */
class MainActivity : Activity(), Bootstrap.Listener {

    private lateinit var screen: MainScreen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val launcher = ProotLauncher(this)
        screen = MainScreen(this, launcher)
        setContentView(screen.root)

        val pi = packageManager.getPackageInfo(packageName, 0)
        screen.terminal.appendLog("Editor v${pi.versionName} (build ${pi.versionCode})")
        Bootstrap(this, launcher, this).start()
    }

    // ---- Bootstrap.Listener (always called on the UI thread) ----
    override fun log(line: String) = screen.terminal.appendLog(line)
    override fun status(text: String) = screen.terminal.setStatus(text)
    override fun busy(busy: Boolean) {
        if (busy) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    override fun ready() = screen.terminal.showTerminals()
    override fun failed() {}

    override fun onPause() {
        screen.editor.saveIfDirty()       // never lose edits when the app goes to background
        super.onPause()
    }

    @Deprecated("kept: targetSdk 28 uses the classic back button")
    override fun onBackPressed() {
        if (!screen.onBack()) moveTaskToBack(true)
    }
}

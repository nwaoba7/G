package dev.you.editor.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import dev.you.editor.MainActivity
import dev.you.editor.terminal.TermSessions

/**
 * Foreground service with a notification, so Android is much less likely to kill
 * the app (and the shells inside it) while it is in the background.
 * Started when the first terminal opens, stopped when the last one closes.
 */
class KeepAliveService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Terminal sessions", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Editor")
            .setContentText("Terminal sessions are running")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(1, n)
        return START_NOT_STICKY
    }

    companion object {
        private const val CHANNEL = "terminals"

        /** Start or stop the service depending on whether any terminal exists. */
        fun sync(ctx: Context) {
            val i = Intent(ctx, KeepAliveService::class.java)
            if (TermSessions.sessions.isNotEmpty()) ctx.startForegroundService(i) else ctx.stopService(i)
        }
    }
}

package dev.you.editor.terminal

import android.util.Log
import android.view.KeyEvent
import android.view.MotionEvent
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalViewClient

/**
 * Glue between the Termux libraries and our [TerminalPane].
 * One object serves as both the session client and the view client
 * (their log* methods have identical signatures).
 */
class TermClient(private val pane: TerminalPane) : TerminalSessionClient, TerminalViewClient {

    // ---------------- TerminalSessionClient ----------------

    override fun onTextChanged(changedSession: TerminalSession) = pane.onSessionText(changedSession)
    override fun onTitleChanged(changedSession: TerminalSession) = pane.onSessionTitle(changedSession)
    override fun onSessionFinished(finishedSession: TerminalSession) = pane.onSessionFinished(finishedSession)
    override fun onCopyTextToClipboard(session: TerminalSession, text: String?) = pane.copyToClipboard(text)
    override fun onPasteTextFromClipboard(session: TerminalSession?) = pane.pasteFromClipboard()
    override fun onBell(session: TerminalSession) {}
    override fun onColorsChanged(session: TerminalSession) {}
    override fun onTerminalCursorStateChange(state: Boolean) {}
    override fun setTerminalShellPid(session: TerminalSession, pid: Int) {}
    override fun getTerminalCursorStyle(): Int? = null

    // ---------------- TerminalViewClient ----------------

    override fun onScale(scale: Float): Float {
        if (scale < 0.9f || scale > 1.1f) {
            pane.changeFontSize(scale > 1f)
            return 1.0f
        }
        return scale
    }

    override fun onSingleTapUp(e: MotionEvent?) = pane.showKeyboard()
    override fun shouldBackButtonBeMappedToEscape() = false
    override fun shouldEnforceCharBasedInput() = true
    override fun shouldUseCtrlSpaceWorkaround() = false
    override fun isTerminalViewSelected() = true
    override fun copyModeChanged(copyMode: Boolean) {}

    override fun onKeyDown(keyCode: Int, e: KeyEvent?, session: TerminalSession?): Boolean {
        // Finished session: Enter closes the tab ("[Process completed - press Enter]")
        if (session != null && !session.isRunning && keyCode == KeyEvent.KEYCODE_ENTER) {
            pane.closeSession(session)
            return true
        }
        return false
    }

    override fun onKeyUp(keyCode: Int, e: KeyEvent?) = false
    override fun onLongPress(event: MotionEvent?) = false

    // Sticky Ctrl/Alt buttons of the extra-keys row apply to the next soft-keyboard key.
    override fun readControlKey() = pane.extraKeys.consumeCtrl()
    override fun readAltKey() = pane.extraKeys.consumeAlt()
    override fun readShiftKey() = false
    override fun readFnKey() = false

    override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession?) = false
    override fun onEmulatorSet() {}

    // ---------------- logging (shared) ----------------

    override fun logError(tag: String?, message: String?) { Log.e(tag, message ?: "") }
    override fun logWarn(tag: String?, message: String?) { Log.w(tag, message ?: "") }
    override fun logInfo(tag: String?, message: String?) { Log.i(tag, message ?: "") }
    override fun logDebug(tag: String?, message: String?) { Log.d(tag, message ?: "") }
    override fun logVerbose(tag: String?, message: String?) { Log.v(tag, message ?: "") }
    override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) { Log.e(tag, message ?: "", e) }
    override fun logStackTrace(tag: String?, e: Exception?) { Log.e(tag, "exception", e) }
}

package dev.you.editor.setup

import android.content.Context
import android.system.Os
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

/** Downloads + extracts the Arch Linux ARM rootfs and prepares it for first use. */
class RootfsInstaller(
    private val ctx: Context,
    private val launcher: ProotLauncher,
    private val log: (String) -> Unit,
    private val status: (String) -> Unit
) {
    private val root get() = launcher.rootDir
    private val partialMarker = File(ctx.filesDir, "arch.partial")

    private val mirrors = listOf(
        "https://ca.us.mirror.archlinuxarm.org/os/ArchLinuxARM-aarch64-latest.tar.gz",
        "http://os.archlinuxarm.org/os/ArchLinuxARM-aarch64-latest.tar.gz"
    )

    fun isInstalled() = File(root, "usr/bin/bash").exists() && !partialMarker.exists()

    fun install() {
        root.deleteRecursively()
        val tgz = File(ctx.filesDir, "arch.tar.gz")
        var ok = false
        for (m in mirrors) {
            try { download(m, tgz); ok = true; break }
            catch (e: Exception) { log("Download failed: $e") }
        }
        if (!ok) throw Exception("All mirrors failed")

        partialMarker.writeText("extracting")
        root.mkdirs()
        extract(tgz, root)
        tgz.delete()
        prepareRootfs()
        partialMarker.delete()
    }

    /** Files the guest needs before the first proot run. */
    private fun prepareRootfs() {
        listOf("dev", "proc", "sys", "tmp", "run", "root").forEach { File(root, it).mkdirs() }
        File(root, "etc/resolv.conf").apply { delete(); writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n") }
        val bashrc = File(root, "root/.bashrc")
        if (!bashrc.exists()) {
            bashrc.writeText(
                "alias ls='ls --color=auto'\nalias grep='grep --color=auto'\n" +
                "PS1='\\[\\e[1;32m\\]\\u@arch\\[\\e[0m\\]:\\[\\e[1;34m\\]\\w\\[\\e[0m\\]\\$ '\n"
            )
        }
    }

    /** One-time pacman fixes needed under proot. Returns true on success. */
    fun runSetup(): Boolean {
        File(root, "root/.editor-setup.sh").writeText(SETUP_SCRIPT)
        val code = launcher.runBlocking(listOf("/bin/sh", "/root/.editor-setup.sh")) { log(it) }
        return code == 0
    }

    private fun download(u: String, dest: File) {
        var url = URL(u)
        var conn: HttpURLConnection? = null
        for (i in 0 until 8) {
            status("Connecting to ${url.host}...")
            val c = url.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "EditorApp")
            val code = c.responseCode
            log("HTTP $code from ${url.host}")
            if (code in 300..399) {
                url = URL(url, c.getHeaderField("Location"))
                c.disconnect()
            } else if (code == 200) {
                conn = c
                break
            } else throw Exception("HTTP $code for $url")
        }
        val c = conn ?: throw Exception("Too many redirects")
        val total = c.contentLengthLong
        log("Size: ${if (total > 0) "${total shr 20} MB" else "unknown"}")
        val t0 = System.currentTimeMillis()
        var last = 0L
        c.inputStream.use { input ->
            dest.outputStream().use { out ->
                val buf = ByteArray(65536)
                var n: Int
                var done = 0L
                while (input.read(buf).also { n = it } > 0) {
                    out.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (now - last > 500) {
                        last = now
                        val secs = (now - t0) / 1000.0 + 0.001
                        val speed = "%.1f".format(done / 1048576.0 / secs)
                        val pct = if (total > 0) " (${done * 100 / total}%)" else ""
                        status("Downloading: ${done shr 20} MB$pct at $speed MB/s")
                    }
                }
            }
        }
        log("Download complete")
    }

    private fun extract(tgz: File, dest: File) {
        var count = 0
        TarArchiveInputStream(GZIPInputStream(tgz.inputStream().buffered())).use { tar ->
            var e = tar.nextTarEntry
            while (e != null) {
                val name = e.name.removePrefix("./")
                val out = File(dest, name)
                val safe = out.toPath().normalize().startsWith(dest.toPath())
                if (name.isNotEmpty() && !name.startsWith("dev/") && safe) {
                    out.parentFile?.mkdirs()
                    when {
                        e.isDirectory -> {
                            out.mkdirs()
                            Os.chmod(out.path, (e.mode and 511) or 448)
                        }
                        e.isSymbolicLink -> {
                            out.delete()
                            Os.symlink(e.linkName, out.path)
                        }
                        e.isLink -> {
                            File(dest, e.linkName.removePrefix("./")).copyTo(out, true)
                            Os.chmod(out.path, (e.mode and 511) or 384)
                        }
                        else -> {
                            out.delete()
                            out.outputStream().use { tar.copyTo(it) }
                            Os.chmod(out.path, (e.mode and 511) or 384)
                        }
                    }
                    if (++count % 200 == 0) status("Extracting: $count files...")
                }
                e = tar.nextTarEntry
            }
        }
        log("Extracted $count files")
    }

    companion object {
        private val SETUP_SCRIPT = """
            export PATH=/usr/local/sbin:/usr/local/bin:/usr/bin
            echo "Configuring pacman for proot..."
            sed -i 's/^CheckSpace/#CheckSpace/' /etc/pacman.conf
            grep -q '^DisableSandbox' /etc/pacman.conf || sed -i '/^\[options\]/a DisableSandbox' /etc/pacman.conf
            echo "Initialising pacman keyring (can take a few minutes)..."
            pacman-key --init || exit 1
            pacman-key --populate archlinuxarm || exit 1
            echo "Setup finished. Run 'pacman -Syu' in the terminal to update packages."
            exit 0
        """.trimIndent() + "\n"
    }
}

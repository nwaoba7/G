package dev.you.editor.ui

import android.app.Activity
import android.app.AlertDialog
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import dev.you.editor.editor.GuestFs
import java.io.File

/** Left drawer: switch between Terminal / Editor, and browse the Arch filesystem. */
class DrawerContent(
    private val activity: Activity,
    private val fs: GuestFs,
    private val callbacks: Callbacks
) : LinearLayout(activity) {

    interface Callbacks {
        fun showTerminal()
        fun showEditor()
        fun openFile(file: File)
        fun fileRemoved(file: File)
    }

    private var cwd: File = fs.home
    private var entries: List<File?> = emptyList()      // null = ".." row
    private val pathView = TextView(activity)
    private val termBtn: TextView
    private val editBtn: TextView
    private val listView = ListView(activity)

    private val adapter = object : BaseAdapter() {
        override fun getCount() = entries.size
        override fun getItem(position: Int): Any? = entries[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val f = entries[position]
            val tv = (convertView as? TextView) ?: TextView(activity).apply {
                textSize = 15f
                setPadding(dp(16), dp(10), dp(16), dp(10))
            }
            tv.text = when {
                f == null -> "⬆  .."
                fs.isDir(f) -> "📁  ${f.name}"
                else -> "      ${f.name}"
            }
            tv.setTextColor(if (f != null && fs.isDir(f)) Colors.ACCENT else Colors.TEXT)
            return tv
        }
    }

    init {
        orientation = VERTICAL
        setBackgroundColor(Colors.BAR)

        addView(TextView(activity).apply {
            text = "Editor"
            textSize = 20f
            setTextColor(Colors.TEXT)
            setPadding(dp(16), dp(24), dp(16), dp(12))
        })
        termBtn = activity.barButton("Terminal") { callbacks.showTerminal() }
        editBtn = activity.barButton("Editor") { callbacks.showEditor() }
        for (b in listOf(termBtn, editBtn)) {
            b.gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
            b.textSize = 16f
            addView(b, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        addView(divider())

        pathView.apply {
            setTextColor(Colors.TEXT_DIM)
            textSize = 12f
            setPadding(dp(16), dp(8), dp(16), dp(4))
        }
        addView(pathView)

        val actions = LinearLayout(activity).apply {
            orientation = HORIZONTAL
            addView(activity.barButton("+ File") { askName("New file") { name -> createFile(name) } })
            addView(activity.barButton("+ Folder") { askName("New folder") { name -> createFolder(name) } })
            addView(activity.barButton("Refresh") { refresh() })
        }
        addView(actions)

        listView.adapter = adapter
        listView.divider = null
        listView.setOnItemClickListener { _, _, pos, _ -> onClick(entries[pos]) }
        listView.setOnItemLongClickListener { _, _, pos, _ -> entries[pos]?.let { onLongClick(it) }; true }
        addView(listView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        refresh()
    }

    private fun divider() = View(activity).apply {
        setBackgroundColor(Colors.DIVIDER)
        layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
    }

    fun setPane(terminal: Boolean) {
        termBtn.setTextColor(if (terminal) Colors.ACCENT else Colors.TEXT)
        editBtn.setTextColor(if (terminal) Colors.TEXT else Colors.ACCENT)
    }

    fun refresh() {
        if (!cwd.isDirectory) cwd = fs.home
        val list = fs.list(cwd)
        entries = (if (cwd.absoluteFile != fs.rootDir.absoluteFile) listOf<File?>(null) else emptyList()) + list
        pathView.text = fs.guestPath(cwd)
        adapter.notifyDataSetChanged()
    }

    // ---------------- interactions ----------------

    private fun onClick(f: File?) {
        if (f == null) {
            cwd = cwd.parentFile?.takeIf { fs.inside(it) } ?: fs.rootDir
            refresh()
            return
        }
        val target = fs.resolve(f)
        if (target.isDirectory) {
            cwd = target.takeIf { fs.inside(it) } ?: f
            refresh()
        } else {
            callbacks.openFile(target)
        }
    }

    private fun onLongClick(f: File) {
        AlertDialog.Builder(activity)
            .setTitle(f.name)
            .setItems(arrayOf("Rename", "Delete")) { _, which ->
                if (which == 0) askName("Rename to", f.name) { name -> rename(f, name) }
                else confirmDelete(f)
            }.show()
    }

    private fun askName(title: String, initial: String = "", onOk: (String) -> Unit) {
        val input = EditText(activity).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setText(initial)
            setSingleLine()
        }
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isEmpty() || n.contains('/') || n == "." || n == "..") {
                    Toast.makeText(activity, "Invalid name", Toast.LENGTH_SHORT).show()
                } else onOk(n)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun createFile(name: String) {
        val f = File(cwd, name)
        try {
            if (f.exists()) throw Exception("already exists")
            f.createNewFile()
            refresh()
            callbacks.openFile(f)
        } catch (e: Exception) { toast("Cannot create: ${e.message}") }
    }

    private fun createFolder(name: String) {
        val f = File(cwd, name)
        if (f.exists() || !f.mkdirs()) toast("Cannot create folder") else refresh()
    }

    private fun rename(f: File, name: String) {
        val dest = File(f.parentFile, name)
        if (dest.exists() || !f.renameTo(dest)) toast("Rename failed")
        else { callbacks.fileRemoved(f); refresh() }
    }

    private fun confirmDelete(f: File) {
        AlertDialog.Builder(activity)
            .setTitle("Delete ${f.name}?")
            .setMessage(if (fs.isDir(f)) "The folder and everything inside it will be deleted." else "This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                safeDelete(f)
                callbacks.fileRemoved(f)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Never follows symlinks, so a link can't make us delete files elsewhere. */
    private fun safeDelete(f: File) {
        if (java.nio.file.Files.isSymbolicLink(f.toPath()) || !f.isDirectory) { f.delete(); return }
        f.listFiles()?.forEach { safeDelete(it) }
        f.delete()
    }

    private fun toast(s: String) = Toast.makeText(activity, s, Toast.LENGTH_SHORT).show()
}

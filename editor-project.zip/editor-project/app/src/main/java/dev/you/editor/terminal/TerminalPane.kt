package dev.you.editor.terminal

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.termux.terminal.TerminalSession
import com.termux.view.TerminalView
import dev.you.editor.service.KeepAliveService
import dev.you.editor.setup.ProotLauncher
import dev.you.editor.ui.Colors
import dev.you.editor.ui.barButton
import dev.you.editor.ui.dp

/**
 * The Terminal screen. Two states:
 *  - setup log (while the rootfs downloads / is configured)
 *  - terminals: tab bar (max 5) + TerminalView + extra-keys row
 */
class TerminalPane(
    private val activity: Activity,
    private val launcher: ProotLauncher
) : FrameLayout(activity) {

    private val client = TermClient(this)
    private val sessions get() = TermSessions.sessions

    // ---- setup log state ----
    private val statusView = TextView(activity).apply {
        text = "Starting..."
        textSize = 16f
        setTextColor(Colors.TEXT)
        setPadding(0, dp(8), 0, dp(8))
    }
    private val logView = TextView(activity).apply {
        textSize = 12f
        typeface = Typeface.MONOSPACE
        setTextColor(Colors.TEXT)
        setTextIsSelectable(true)
    }
    private val setupBox = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Colors.BG)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        addView(statusView)
        addView(
            ScrollView(activity).apply { addView(logView) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
    }

    // ---- terminal state ----
    val terminalView = TerminalView(activity, null).apply {
        isFocusable = true
        isFocusableInTouchMode = true
    }
    private val tabRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
    val extraKeys = ExtraKeysBar(
        activity,
        sendKey = { code, mod -> TermSessions.current?.let { terminalView.handleKeyCode(code, mod) }; Unit },
        sendText = { text -> TermSessions.current?.write(text); Unit },
        paste = { pasteFromClipboard() }
    )
    private val termBox = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Colors.BG)
        addView(buildTabBar())
        addView(terminalView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(extraKeys, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private var fontDp = 12

    init {
        addView(setupBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        addView(termBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        terminalView.setTerminalViewClient(client)
        terminalView.setTextSize(dp(fontDp))
        showSetup()
    }

    private fun buildTabBar(): LinearLayout {
        val scroll = HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        }
        return LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Colors.BAR)
            gravity = Gravity.CENTER_VERTICAL
            addView(scroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(activity.barButton("+") { newTab() })
        }
    }

    // ---------------- setup log ----------------

    fun appendLog(line: String) { logView.append(line + "\n") }
    fun setStatus(text: String) { statusView.text = text }

    fun showSetup() {
        setupBox.visibility = View.VISIBLE
        termBox.visibility = View.GONE
    }

    /** Called once the rootfs is ready (or already was). */
    fun showTerminals() {
        setupBox.visibility = View.GONE
        termBox.visibility = View.VISIBLE
        // Re-attach sessions that survived an Activity re-creation.
        sessions.forEach { it.updateTerminalSessionClient(client) }
        if (sessions.isEmpty()) newTab()
        else select(TermSessions.current ?: sessions.last())
    }

    fun onShown() {
        if (termBox.visibility == View.VISIBLE) terminalView.requestFocus()
    }

    // ---------------- tabs ----------------

    fun newTab() {
        if (sessions.size >= TermSessions.MAX) {
            Toast.makeText(activity, "Maximum ${TermSessions.MAX} terminals", Toast.LENGTH_SHORT).show()
            return
        }
        val spec = launcher.interactiveShell()
        val s = TerminalSession(spec.path, spec.cwd, spec.args, spec.env, 2000, client)
        s.mSessionName = TermSessions.nextName()
        sessions.add(s)
        KeepAliveService.sync(activity)
        select(s)
    }

    fun select(s: TerminalSession) {
        TermSessions.current = s
        terminalView.attachSession(s)
        rebuildTabs()
        terminalView.requestFocus()
        terminalView.onScreenUpdated()
    }

    fun closeSession(s: TerminalSession) {
        val idx = sessions.indexOf(s)
        if (idx < 0) return
        s.finishIfRunning()
        sessions.removeAt(idx)
        KeepAliveService.sync(activity)
        if (sessions.isEmpty()) {
            TermSessions.current = null
            newTab()                      // always keep one terminal open
        } else if (TermSessions.current === s) {
            select(sessions[minOf(idx, sessions.size - 1)])
        } else {
            rebuildTabs()
        }
    }

    private fun rebuildTabs() {
        tabRow.removeAllViews()
        for (s in sessions) {
            val selected = s === TermSessions.current
            val label = " ${s.mSessionName}${if (s.isRunning) "" else " ✕"} "
            val tab = activity.barButton(label) { select(s) }
            tab.setTextColor(if (selected) Colors.ACCENT else Colors.TEXT_DIM)
            if (selected) tab.setBackgroundColor(Colors.BAR_ACTIVE)
            tab.setOnLongClickListener {   // long-press = close tab
                closeSession(s); true
            }
            tabRow.addView(tab)
        }
    }

    // ---------------- callbacks from TermClient ----------------

    fun onSessionText(s: TerminalSession) {
        if (s === TermSessions.current) terminalView.onScreenUpdated()
    }

    fun onSessionTitle(s: TerminalSession) { /* tab names are numbers; titles ignored */ }

    fun onSessionFinished(s: TerminalSession) = rebuildTabs()

    fun showKeyboard() {
        terminalView.requestFocus()
        val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(terminalView, InputMethodManager.SHOW_IMPLICIT)
    }

    fun changeFontSize(increase: Boolean) {
        fontDp = (fontDp + if (increase) 1 else -1).coerceIn(7, 28)
        terminalView.setTextSize(dp(fontDp))
    }

    fun copyToClipboard(text: String?) {
        if (text.isNullOrEmpty()) return
        val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("terminal", text))
    }

    fun pasteFromClipboard() {
        val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(activity)?.toString()
        if (!text.isNullOrEmpty()) TermSessions.current?.emulator?.paste(text)
    }
}
